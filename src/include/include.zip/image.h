#ifndef IMAGE_H
#define IMAGE_H

class Image{
private:
	unsigned char *data;
	int rows, cols;
	char type[3];
	
	void dataFree();

protected:
	void dataAlloc();
	

public:
	Image();
	Image(int rows, int cols);
	virtual ~Image();

	int getRows();

	int getCols();

	void readFile(const char *name);

	void writeFile(const char *name);

	unsigned char* getData();

	unsigned char* getData(int line_start);
	
	virtual int getPixelSize();
	virtual Image *createSizeCopy();

};

class grayImage : public Image {
public:
	grayImage();
	grayImage(int rows, int columns);
	~grayImage();
	int getPixelSize();
	grayImage *createSizeCopy();
};

class rgbImage : public Image {
public:
	rgbImage();
	rgbImage(int rows, int columns);
	~rgbImage();
	int getPixelSize();
	rgbImage *createSizeCopy();
};


#endif
